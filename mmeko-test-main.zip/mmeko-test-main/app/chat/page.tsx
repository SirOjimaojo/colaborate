export default function Chat() {
    return <h1>Hello World</h1>
}