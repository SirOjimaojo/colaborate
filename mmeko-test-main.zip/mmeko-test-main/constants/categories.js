export const categoryList = [
    {
        id:1,
      imgURL: "/images/vcs.png",
      label: "Vcs",
    },

    {
        id:2,
      imgURL: "/images/hook-up.png",
      label: "Hookup",
    },
    
    {
        id:3,
      imgURL: "/images/date.png",
      label: "Date",
    },
    {
        id:4,
      imgURL: "/images/escort.png",
      label: "Escort",
    },
    {
        id:5,
        imgURL: "/images/massage.png",
        label: "Massage",
      },
      {
        id:6,
        imgURL: "/images/girlfriend.png",
        label: "Girlfriend",
      },
      
      ];
  
