export const sidebarLinks = [
    {
      imgURL: "/assets/home.svg",
      route: "/",
      label: "Home",
    },

    {
      imgURL: "/assets/models.svg",
      route: "/models",
      label: "Models",
    },
    
    {
      imgURL: "/assets/activity.svg",
      route: "/activity",
      label: "Activity",
    },
    {
      imgURL: "/assets/create.svg",
      route: "/create",
      label: "Create",
    },
    {
      imgURL: "/assets/chat.svg",
      route: "/chat",
      label: "Chat",
    },
    
    
  ];
  
